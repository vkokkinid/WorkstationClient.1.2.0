﻿
namespace Plexscape.Samples
{
    /// <summary>
    /// Constant values used by the samples.
    /// </summary>
    public class SampleConstants
    {
        #region User profile properties (Arbitrary sample values, can be anything)

        /// <summary>
        /// The first name of the user (Optional).
        /// </summary>
        public static readonly string UP_FirstName = "firstName";

        /// <summary>
        /// The last name of the user (Optional).
        /// </summary>
        public static readonly string UP_LastName = "lastName";

        /// <summary>
        /// The nickname of the user (Optional).
        /// </summary>
        public static readonly string UP_NickName = "nickName";

        /// <summary>
        /// The company name of the user (Optional).
        /// </summary>
        public static readonly string UP_CompanyName = "companyName";

        /// <summary>
        /// The birthday of the user (Optional).
        /// </summary>
        public static readonly string UP_Birthday = "birthday";

        #endregion
    }
}
