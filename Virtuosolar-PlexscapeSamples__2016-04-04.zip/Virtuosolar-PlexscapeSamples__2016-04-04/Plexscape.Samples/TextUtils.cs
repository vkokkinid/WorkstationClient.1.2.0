﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Plexscape.Samples
{
    /// <summary>
    /// Utility class for common text related tasks.
    /// </summary>
    public static class TextUtils
    {
        /// <summary>
        /// Helper method that tokenizes the given delimited string.
        /// 
        /// Note that we trim any leading/trailing whitespaces from each token.
        /// </summary>
        public static IEnumerable<string> ExtractDelimitedValues(string text, char delimiter = ',')
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return new List<string>();
            }
            return text.Split(delimiter).Select(s => s.Trim());
        }

        /// <summary>
        /// Helper method that extracts key-value pairs from a comma-separated list of ':' separated strings.
        /// An optional list of desired keys can be passed when only specific pairs must be returned.
        /// </summary>
        public static Dictionary<string, string> ExtractKeyValuePairs(string text, params string[] keyList)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            IEnumerable<string> tokens;
            foreach (string keyValue in ExtractDelimitedValues(text))
            {
                tokens = keyValue.Split(':').Select(s => s.Trim());
                if (tokens.Count() != 2)
                {
                    throw new ArgumentException(string.Format("KeyValue pair '{0}' is not well formed!", keyValue));
                }

                if (keyList.Length > 0 && !keyList.Contains(tokens.First()))
                {
                    continue;   // Ignore pairs when specific keys are requested
                }

                dictionary.Add(tokens.First(), tokens.Last());
            }

            return dictionary;
        }
    }
}
