﻿using Plexscape.WebServices.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace Plexscape.Samples
{
    /// <summary>
    /// Sample console application to demonstrate the use of Plexscape's workstation client.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// An reference to your own application that is provided by Plexscape.
        /// </summary>
        private static readonly string PX_APP_REFERENCE = <YOUR_APPLICATION_REFERENCE>;

        static void Main(string[] args)
        {
            OnlineSession();
        }

        /// <summary>
        /// Sample of various client interactions with the Plexscape web services.
        /// </summary>
        private static void OnlineSession()
        {
            IDisplay display = new ConsoleDisplay();
            ClientSession session = new ClientSession();

            // If needed, you can provide your own web proxy object
            // and have control over HTTP access, e.g.
            //      webProxy = ProxyUtils.GetProxy(...);
            // Note that passing null (the default) yields 'ProxyConnectionMode.System'
            IWebProxy webProxy = null; 

            // Load a client instance into the session wrapper
            int statusCode = session.LoadClient(display, PX_APP_REFERENCE, webProxy);
            if (statusCode >= ResponseCode.SERVER_ERROR_BASE)
            {
                return;     // Nothing more to do, here
            }

            Console.WriteLine("*** Starting client session... ***");

            // Start the session
            statusCode = session.Start();

            // If not attached to a subscription yet, we must decide upon a desired type:
            // - Start a trial that is anonymous.
            // - Start a trial that demands prior registration.
            // - Use an existing subscription reference, usually created beforehand.
            if (statusCode == ResponseCode.WorkstationNotActivatedYet)
            {
                statusCode = NotActivatedYetScenarios(session);
            }

            // Every registered trial is a two-step process and needs confirmation
            if (statusCode == ResponseCode.PendingRegistration ||
                statusCode == ResponseCode.PendingConfirmation)
            {
                statusCode = RegistrationScenarios(session);
            }

            // A status code less than SERVER_ERROR_BASE implies a valid session
            if (statusCode < ResponseCode.SERVER_ERROR_BASE)
            {
                statusCode = CommonUsageScenarios(session);
            }
                
            // If an error occurs, clearing workstation data might fix it
            if (statusCode >= ResponseCode.SERVER_ERROR_BASE)
            {
                Console.WriteLine("  You might try to modify or clear current subscription data to fix the problem.");

                // It's wise to display troubleshooting info, here
                session.ShowClientInfo();
            }

            // Terminate the current session
            session.End();
            
            Console.WriteLine("*** Client session ended. ***");
        }

        /// <summary>
        /// Possible scenarios when a subscription is not activated yet. You can choose
        /// 1. One of the available anonymous trials.
        /// 2. One of the available registered trials.
        /// 3. The pre-existing "business" subscription that allows up to three stations
        ///   while only one of them can work at a time.
        /// </summary>
        /// <returns>The latest status code.</returns>
        private static int NotActivatedYetScenarios(ClientSession session)
        {
            int selection = 0;
            int statusCode = ResponseCode.OK;

            string question =
                "- Type '1' for anonymous trial, '2' for registered trial or '3' to use an existing subscription:";

            do
            {
                Console.WriteLine(question);
                if (!Int32.TryParse(Console.ReadLine(), out selection))
                {
                    selection = 0;
                }

                switch (selection)
                {
                    case 1:
                        {
                            // Get all available anonymous trials
                            statusCode = session.ShowAvailableTrials(false);
                            if (statusCode == ResponseCode.OK)
                            {
                                // Select one of them
                                Console.WriteLine(
                                    "  Provide a service plan reference from the keys listed above (no apostrophes):");
                                string planReference = Console.ReadLine();
                                statusCode = session.AnonymousTrial(planReference);
                            }
                        }
                        break;
                    case 2:
                        {
                            // Get all available registered trials
                            statusCode = session.ShowAvailableTrials(true);
                            if (statusCode == ResponseCode.OK)
                            {
                                // Select one of them
                                Console.WriteLine(
                                    "  Provide a service plan reference from the keys listed above (no apostrophes):");
                                string planReference = Console.ReadLine();

                                // An email is the simplest way to confirm a user
                                Console.WriteLine(
                                    "  Provide your email address. A confirmation code will be sent to you:");
                                string email = Console.ReadLine();

                                // You can use any arbitrary combination of application specific key-value pairs, here
                                Dictionary<string, string> userData = new Dictionary<string, string>() {
                                    { SampleConstants.UP_FirstName, "Harry" },
                                    { SampleConstants.UP_LastName, "Callahan" },
                                    { SampleConstants.UP_NickName, "Dirty" },
                                    { SampleConstants.UP_Birthday , "1970-01-01" }
                                };
                                statusCode = session.StartRegisteredTrial(planReference, email, userData);
                            }
                        }
                        break;
                    case 3:
                        // Activate the current workstation under an pre-existing subscription.
                        Console.WriteLine(
                            "  Provide the reference of a subscription that you have explicitly created:");
                        string subscriptionReference = Console.ReadLine();
                        statusCode = session.BeginService(subscriptionReference);
                        break;
                }
            }
            while (selection < 1 || selection > 3);

            return statusCode;
        }

        /// <summary>
        /// Possible scenarios when a registered licence has been initiated but not confirmed yet:
        /// 1. Complete confirmation applying the code received in the provided email address.
        /// 2. Request to have a new code sent, because the previous has expired/was lost etc
        ///   and then complete confirmation.
        /// 3. Provide a different email (from now on, used as current) to receive a new confirmation code
        ///   and then complete confirmation.
        /// </summary>
        /// <returns>The latest status code.</returns>
        private static int RegistrationScenarios(ClientSession session)
        {
            int selection = 0;
            int statusCode = ResponseCode.OK;

            do
            {
                Console.WriteLine("- Type '1' to complete confirmation with the received code,");
                Console.WriteLine(" '2' to request a new code sent to your current email or ");
                Console.WriteLine(" '3' to provide a different email for the registration:");

                if (!Int32.TryParse(Console.ReadLine(), out selection))
                {
                    selection = 0;
                }

                switch (selection)
                {
                    case 1:
                        statusCode = AskConfirmationCode(session);
                        break;
                    case 2:
                        {
                            statusCode = session.ResetPendingRegistration();
                            if (statusCode == ResponseCode.PendingConfirmation)
                            {
                                statusCode = AskConfirmationCode(session);
                            }
                        }
                        break;
                    case 3:
                        {
                            Console.WriteLine(
                                "  Provide a new email address. A confirmation code will be sent to it:");
                            string email = Console.ReadLine();

                            statusCode = session.RegisterDifferentEmail(email, null);
                            if (statusCode == ResponseCode.PendingConfirmation)
                            {
                                statusCode = AskConfirmationCode(session);
                            }
                        }
                        break;
                }
            }
            while (selection < 1 || selection > 3);

            return statusCode;
        }

        /// <summary>
        /// Possible scenarios when the subscription is activated:
        /// 1. Get status of service which returns current subscription/workstation data.
        /// 2. Use the available File API functionality.
        /// 3. Check whether a particular command is supported by the current service plan.
        /// 4. Check if a resource-bound command is allowed or the resource limit was exceeded.
        /// 5. Exit current session.
        /// </summary>
        /// <returns>The latest status code.</returns>
        private static int CommonUsageScenarios(ClientSession session)
        {
            int selection = 0;
            int statusCode = ResponseCode.OK;

            do
            {
                Console.WriteLine();
                Console.WriteLine("- Type '1' to get service status, '2' to use the File API functions,");
                Console.WriteLine(" '3' to see command availability, '4' to check if a resource-bound command is allowed,");
                Console.WriteLine(" or '5' to exit:");

                if (!Int32.TryParse(Console.ReadLine(), out selection))
                {
                    selection = 0;
                }

                switch (selection)
                {
                    case 1:
                        {
                            // Display specific or full status
                            if (AskFullStatus())
                            {
                                statusCode = session.RetrieveCurrentStatus();
                            }
                            else
                            {
                                // Get some values, selectively.
                                // Optimized call, faster than full status and suitable for GUI checks
                                string strValue;
                                statusCode = session.GetCurrentStatusValue<string>(DtoKeys.SubName, out strValue);
                                DateTime? subEndDate;
                                statusCode = session.GetCurrentStatusValue<DateTime?>(DtoKeys.SubEndDate, out subEndDate);
                                int? durationInDays;
                                statusCode = session.GetCurrentStatusValue<int?>(DtoKeys.DurationDays, out durationInDays);
                                bool isTrial;
                                statusCode = session.GetCurrentStatusValue<bool>(DtoKeys.IsTrial, out isTrial);
                            }
                        }
                        break;
                    case 2:
                        statusCode = FileApiUsage(session);
                        break;
                    case 3:
                        {
                            // Command availability check.
                            // Intended for GUI control logic regarding commands that only work under specific service plan(s).
                            // Equivalent to parsing the status value of key 'allowedCmds'.
                            Console.WriteLine("  Provide a command name to see if it is available.");
                            string cmdName = Console.ReadLine();
                            statusCode = session.CommandAvailableCheck(cmdName);
                        }
                        break;
                    case 4:
                        {
                            // Check specifically for resource-bound commands.
                            // A request is sent to server each time to determine if the related resources have run out or not.
                            Console.WriteLine("  Provide a resource-bound command name to check whether resource limits are reached.");
                            string cmdName = Console.ReadLine();
                            statusCode = session.CommandExecuteCheck(cmdName);
                        }
                        break;
                    case 5:
                        break;      // Keep looping
                }
            }
            while (selection != 5);

            if (selection == 5)
            {
                statusCode = ResponseCode.OK;
            }

            return statusCode;
        }

        /// <summary>
        /// Possible scenarios of how to monitor and sync a particular file between workstations
        /// of the same subscription.<br/>
        /// 
        /// Each desired type of file must be predefined via the management console in order to become available.
        /// In particular, one must configure a unique descriptor needed to identify the particular monitored content.
        /// 
        /// A workstation has the ability to:
        /// 1) Create the first instance of the monitored file.
        /// 2) Check to see if a newer version exists.
        /// 3) Retrieve the latest version.
        /// 4) Set the latest version with a new file.
        /// 5) View history of changes.
        /// </summary>
        /// <returns>The latest status code.</returns>
        private static int FileApiUsage(ClientSession session)
        {
            int selection = 0;
            int statusCode = ResponseCode.OK;

            string fileDescriptor = "SettingsForAccount";   // A pre-configured name (set in the web console)

            do
            {
                Console.WriteLine();
                Console.WriteLine("- Type '1' to store first instance of the file, '2' to synchronize this workstation,");
                Console.WriteLine(" '3' to get latest version, '4' to set the latest version,");
                Console.WriteLine(" '5' to show history of recent changes or '6' to exit File API:");

                if (!Int32.TryParse(Console.ReadLine(), out selection))
                {
                    selection = 0;
                }

                switch (selection)
                {
                    case 1:
                        {
                            // Create the first instance of the monitored file, if not exists yet
                            Console.WriteLine("  Drag and drop a file here and press <ENTER> to upload its contents.");
                            string filepath = Console.ReadLine();
                            statusCode = session.CreateFileIfNotExists(fileDescriptor, filepath.Replace("\"", ""));
                        }
                        break;
                    case 2:
                        {
                            // Sync with server and handle newer version, if one exists.
                            statusCode = session.SyncFileForWorkstation(fileDescriptor);
                        }
                        break;
                    case 3:
                        {
                            // Get latest version
                            statusCode = session.GetLatestFileVersion(fileDescriptor);
                        }
                        break;
                    case 4:
                        {
                            // Try to update with a newer version
                            Console.WriteLine("  Drag and drop a file here and press <ENTER> to upload its contents.");
                            string filepath = Console.ReadLine();

                            // Read raw byte content from disk (in an everyday scenario this might already be in-memory)
                            byte[] content = File.ReadAllBytes(filepath.Replace("\"", ""));

                            // Try to upload to server
                            statusCode = session.UploadNewFileVersion(fileDescriptor, content);
                        }
                        break;
                    case 5:
                        {
                            // Get history of recent changes
                            statusCode = session.ShowFileHistory(fileDescriptor);
                        }
                        break;
                    case 6:
                        break;      // Keep looping
                }
            }
            while (selection != 6);

            if (selection == 6)
            {
                statusCode = ResponseCode.OK;
            }

            return statusCode;
        }

        #region Helpers

        /// <summary>
        /// Helper method that asks the user whether to show full status or specific values.
        /// </summary>
        private static bool AskFullStatus()
        {
            Console.WriteLine("   Do you want to see full status? (Type 'Y', otherwise specific values are displayed).");
            string showFullStatus = Console.ReadLine();
            return showFullStatus.ToUpper().Equals("Y");
        }

        /// <summary>
        /// Helper method that asks the user to input the registration confirmation code that he has received.
        /// </summary>
        private static int AskConfirmationCode(ClientSession session)
        {
            Console.WriteLine("  Paste or type the confirmation code that you have received.");
            string confirmationCode = Console.ReadLine();
            return session.ConfirmRegisteredTrial(confirmationCode);
        }

        #endregion
    }
}
