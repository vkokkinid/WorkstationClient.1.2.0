﻿
namespace Plexscape.Samples
{
	/// <summary>
	/// Response codes defined by Plexscape.
	/// </summary>
	internal class ResponseCode
	{
		#region Success

		/// <summary>
		/// General success.
		/// </summary>
		public static readonly int OK = 0;

		#endregion

		/// <summary>
		/// The "base" for server errors.
		/// Note that all related errors will be between this value and CLIENT_ERROR_BASE.
		/// </summary>
		public static readonly int SERVER_ERROR_BASE = 10000;

		#region Server errors

		/// <summary>
		/// When the calling workstation does not exist.
		/// </summary>
		public static readonly int WorkstationNotExists = 10001;

		/// <summary>
		/// When the calling workstation is blocked.
		/// </summary>
		public static readonly int WorkstationNotAllowed = 10002;

		/// <summary>
		/// When a caller's checksum is not matched against the known values.
		/// </summary>
		public static readonly int UnauthorizedCaller = 10003;

		/// <summary>
		/// When the calling workstation has not been activated yet.
		/// </summary>
		public static readonly int WorkstationNotActivatedYet = 10010;

		/// <summary>
		/// When the subscription is not active.
		/// </summary>
		public static readonly int SubscriptionDeactivated = 10011;

		/// <summary>
		/// When the subscription is blocked.
		/// </summary>
		public static readonly int SubscriptionNotAllowed = 10012;

		/// <summary>
		/// When the subscription has expired.
		/// </summary>
		public static readonly int SubscriptionExpired = 10013;
		
		/// <summary>
		/// When a constraint (tag limit) is violated.
		/// </summary>
		public static readonly int ConstraintViolated = 10014;

		/// <summary>
		/// When the calling ip is not allowed.
		/// </summary>
		public static readonly int CallerIpNotAllowed = 10015;

		/// <summary>
		/// When the caller has a pending registration (usually for trial).
		/// </summary>
		public static readonly int PendingRegistration = 10016;

		/// <summary>
		/// When the caller has a pending confirmation (usually for registered trial).
		/// </summary>
		public static readonly int PendingConfirmation = 10017;

		/// <summary>
		/// When a request fails authentication.
		/// </summary>
		public static readonly int AuthenticationFailed = 10018;

		/// <summary>
		/// When a provided extension session key is not valid.
		/// </summary>
		public static readonly int UnauthorizedExtension = 10019;

		/// <summary>
		/// When a session token key for an extension has expired.
		/// </summary>
		public static readonly int ExtensionSessionKeyExpired = 10020;

		//
		//...
		//

		/// <summary>
		/// General error emitted when the request data are not valid.
		/// </summary>
		public static readonly int BadRequestData = 10100;

		/// <summary>
		/// When the command data of the incoming request are not valid.
		/// </summary>
		public static readonly int InvalidCommand = 10101;

		/// <summary>
		/// When the requested command is not allowed to the caller.
		/// </summary>
		public static readonly int NotAllowedCommand = 10102;

		/// <summary>
		/// When the requested subscription does not exist.
		/// </summary>
		public static readonly int InvalidSubscriptionReferenceSent = 10103;
		
		/// <summary>
		/// When the requested service plan does not exist or is not valid.
		/// </summary>
		public static readonly int InvalidServicePlanReference = 10104;

		/// <summary>
		/// When the requested application does not exist or is not valid.
		/// </summary>
		public static readonly int InvalidApplicationReference = 10105;
		
		/// <summary>
		/// When an expected email address is missing or not valid.
		/// </summary>
		public static readonly int InvalidEmailSent = 10106;

		/// <summary>
		/// When a provided confirmation code is not valid.
		/// </summary>
		public static readonly int InvalidConfirmationCodeSent = 10107;


		/// <summary>
		/// General error emitted when the server operation could not be completed 
		/// due to some internal logic error.
		/// </summary>
		public static readonly int InternalLogicError = 15000;

		#endregion

		/// <summary>
		/// The "base" for client errors.
		/// Note that all related errors will be between this value and CUSTOM_ERROR_BASE.
		/// </summary>
		public static readonly int CLIENT_ERROR_BASE = 20000;

		#region Client errors

		/// <summary>
		/// When the client failed to load.
		/// </summary>
		public static readonly int FailedToInitialize = 20001;
		
		/// <summary>
		/// When the client tries to send a request with invalid argument(s).
		/// </summary>
		public static readonly int InvalidRequestArgument = 20002;

		/// <summary>
		/// When an unexpected error occurs at client-side.
		/// </summary>
		public static readonly int InvalidClientOperation = 20003;

		/// <summary>
		/// When a trial reference is not found in the available public service plans.
		/// </summary>
		public static readonly int InvalidTrialServicePlanReference = 20004;
		
		/// <summary>
		/// When an invalid email address is provided.
		/// </summary>
		public static readonly int InvalidEmail = 20005;

		/// <summary>
		/// When an invalid confirmation code is provided.
		/// </summary>
		public static readonly int InvalidConfirmationCode = 20006;

		/// <summary>
		/// When an invalid confirmation code is provided.
		/// </summary>
		public static readonly int InvalidSubscriptionReference = 20007;

		//
		//...
		//

		/// <summary>
		/// When the client hasn't performed a successful StartSession() yet.
		/// </summary>
		public static readonly int NotCheckedOutYet = 20010;

		#region File API

		/// <summary>
		/// When an unexpected error occurs during a File API operation.
		/// </summary>
		public static readonly int InvalidFileApiOperation = 20100;
		
		/// <summary>
		/// When the requested file is not monitored by the server.
		/// </summary>
		public static readonly int FileNotMonitored = 20101;

		/// <summary>
		/// When the monitored file does not exist in the storage container.
		/// </summary>
		public static readonly int FileNotFound = 20102;

		/// <summary>
		/// When the monitored file has not been synced yet.
		/// </summary>
		public static readonly int FileNotSyncedYet = 20103;

		/// <summary>
		/// When the monitored file could not be backed up before the update.
		/// </summary>
		public static readonly int FileFailedToBackup = 20104;

		/// <summary>
		/// When the monitored file could not be updated because a newer version exists.
		/// </summary>
		public static readonly int FileNewerVersionExists = 20105;

		/// <summary>
		/// When the monitored file could not be created because one already exists.
		/// </summary>
		public static readonly int FileCreateAlreadyExists = 20106;

		/// <summary>
		/// When the monitored file could not be created because is being uploaded by someone else.
		/// </summary>
		public static readonly int FileCreateOtherUploading = 20106;
		
		#endregion

		//
		//...
		//

		/// <summary>
		/// When the client fails to send an http request.
		/// </summary>
		public static readonly int FailedToSendRequest = 21000;

		/// <summary>
		/// When the client fails to serialize the contents of an http request.
		/// </summary>
		public static readonly int FailedToSerializeRequest = 21001;
		
		/// <summary>
		/// When the client receives a response that could not be parsed.
		/// </summary>
		public static readonly int FailedToParseResponse = 21002;

		/// <summary>
		/// When the client receives an empty http response while a DTO is expected.
		/// </summary>
		public static readonly int MissingResponseData = 21003;

		/// <summary>
		/// When a client action cannot be performed in offline mode.
		/// </summary>
		public static readonly int UnableToExecuteDueToOffline = 21004;

		
		#endregion

		/// <summary>
		/// The "base" for custom errors, i.e. errors defined by 3rd-party developers.
		/// All values greater than CUSTOM_ERROR_BASE are available to use.
		/// </summary>
		public static readonly int CUSTOM_ERROR_BASE = 30000;
	}
}
