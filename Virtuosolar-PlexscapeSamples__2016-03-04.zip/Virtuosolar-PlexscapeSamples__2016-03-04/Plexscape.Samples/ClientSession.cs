﻿using Plexscape.WebServices.Core;
using Plexscape.WebServices.WorkstationClient;
using Plexscape.WebServices.WorkstationClient.Cloud;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace Plexscape.Samples
{
    /// <summary>
    /// A typical session a client might have with the Plex server.
    /// </summary>
    /// <remarks>
    /// This class is intended merely as an integration suggestion.
    /// Feel free to experiment upon the logic here.
    /// </remarks>
    public class ClientSession
    {
        #region Private Properties

        /// <summary>
        /// Use a single client object per session.
        /// </summary>
        private IWorkstationClient Client;

        /// <summary>
        /// Used to display output messages.
        /// </summary>
        private IDisplay Display;

        #endregion

        /// <summary>
        /// Create and initialize a new instance of IWorkstationClient that will be used from now on.
        /// </summary>
        public int LoadClient(IDisplay display, string appReference, IWebProxy webProxy = null)
        {
            Display = display;

            // Get an instance of the workstation client
            Client = WorkstationClientFactory.CreateClient();

            // Populate a dictionary with (client-side) environment values
            Dictionary<string, string> environmentData = new Dictionary<string, string>() {
                { DtoKeys.ApplicationReference, appReference },  // Required
                { DtoKeys.Product, "Virtuosolar" },         // Required
                { DtoKeys.Version, "1.?.?.?" },             // Required
                { DtoKeys.StationName, Environment.MachineName + "_VisoTestStation" },     // Optional
            };

            ClientResult cr = Client.LoadClient(environmentData, webProxy);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "LOAD");
            }

            return GetStatusCode(cr);
        }

        /// <summary>
        /// The initial call to make after a client is loaded.
        /// Depending on the success or not, one can decide what further actions to invoke.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int Start()
        {
            ClientResult cr = Client.StartSession();
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "START_SESSION");
                return GetStatusCode(cr);
            }

            // Get current status to provide info to caller
            return RetrieveCurrentStatus();
        }

        /// <summary>
        /// End session and free client resources.
        /// <summary> 
        public void End()
        {
            ClientResult cr = Client.EndSession();
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "END_SESSION");
            }
        }

        /// <summary>
        /// Get the current service status and display the retrieved data.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int RetrieveCurrentStatus()
        {
            // Try to get status data
            ClientResult<Dictionary<string, string>> cr = Client.GetServiceStatus();
            
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "STATUS");
            }
            
            // Data are available even in case of error
            Display.ShowResponseData("  All status values:", cr.Value);

            return GetStatusCode(cr);
        }

        /// <summary>
        /// Get a specific value from the current status.
        /// Especially usefull to retrieve complex objects.
        /// </summary>
        /// <param name="dtoKey">The key of the requested status property, as declared in .</param>
        /// <param name="value">(Output) The deserialized value.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int GetCurrentStatusValue<T>(string dtoKey, out T value)
        {
            // Try to get status data
            ClientResult<T> cr = Client.GetStatusValueForKey<T>(dtoKey);

            // Data are available even in case of error
            value = cr.Value;

            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "STATUS");
            }
            else
            {
                Display.ShowResponseData(
                    string.Format("  Status value for '{0}': {1}", dtoKey, value));
           }

            return GetStatusCode(cr);
        }

        /// <summary>
        /// Get client information useful for troubleshooting purposes.
        /// This call will never emit an error.
        /// </summary>
        public void ShowClientInfo()
        {
            Dictionary<string, string> info = Client.GetClientInfo();
            Display.ShowResponseData("\n  Client information:", info);
        }

        #region Workstation Activation

        /// <summary>
        /// Display the trials supported by the current application.
        /// </summary>
        /// <param name="needsRegistration">True if we want registered trials, false for anonymous ones.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int ShowAvailableTrials(bool needsRegistration)
        {
            // Create a search filter depending on the given input
            Tuple<string, bool>[] searchFilter = new Tuple<string, bool>[] {
                new Tuple<string, bool>(DtoKeys.IsTrial, true),
                new Tuple<string, bool>(DtoKeys.NeedsRegistration, needsRegistration)
            };

            // Get the requested service plans
            ClientResult<Dictionary<string, string>> cr = Client.GetServicePlans(searchFilter);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "GET_PLANS");
                return GetStatusCode(cr);
            }

            // Show results in output
            Display.ShowResponseData(
                string.Format("Availabe {0} trial service plans:", needsRegistration ? "registered" : "anonymous" ),
                cr.Value);

            return ResponseCode.OK;
        }

        /// <summary>
        /// Start an anonymous trial, i.e. a trial with the least possible resources (e.g. limited expiration etc).
        /// Note that in this case, no user identification data are required.
        /// </summary>
        /// <param name="planReference">A reference to an existing </param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int AnonymousTrial(string planReference)
        {
            // Start anonymous trial
            ClientResult cr = Client.BeginTrial(planReference);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "BEGIN_ANONYMOUS");
                return GetStatusCode(cr);
            }

            // Now that we have a valid trial we can call StartSession() again 
            return this.Start();
        }

        /// <summary>
        /// Initiate a registered trial, i.e. an "enhanced" trial with email and (optional) user profile data.<br/>
        /// This is a two step process, where the provided email is used as a recipient of a confirmation code.
        /// The particular code will be used to complete the registration.
        /// </summary>
        /// <param name="email">A valid email address.</param>
        /// <param name="userData">Optional user profile data (can be null).</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int StartRegisteredTrial(string planReference, string email, Dictionary<string, string> userData)
        {
            // Start a registered trial
            ClientResult cr = Client.BeginTrial(planReference);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "BEGIN_REGISTER");
                return GetStatusCode(cr);
            }

            cr = Client.Register(email, userData);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "REGISTER");
                return GetStatusCode(cr);
            }

            // NOTE:  Don't call Start() yet, a confirmation is pending

            return RetrieveCurrentStatus();
        }

        /// <summary>
        /// Submit a confirmation code and start using the registered trial.
        /// </summary>
        /// <param name="confirmationCode"></param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int ConfirmRegisteredTrial(string confirmationCode)
        {
            // Confirm the registration
            ClientResult cr = Client.ConfirmRegistration(confirmationCode);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "CONFIRM_REGISTER");
                return GetStatusCode(cr);
            }

            // Now that we have a valid trial we can call StartSession() again 
            return this.Start();
        }

        /// <summary>
        /// Request a new confirmation code for a pending registration.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int ResetPendingRegistration()
        {
            ClientResult cr = Client.ResetPendingRegistration();
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "RESET_REGISTER");
                return GetStatusCode(cr);
            }

            return RetrieveCurrentStatus();
        }

        /// <summary>
        /// Request a new confirmation code to be sent to a different email (because of a previous typo etc).
        /// </summary>
        /// <param name="email">A valid email address.</param>
        /// <param name="userData">Optional user profile data (can be null).</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int RegisterDifferentEmail(string email, Dictionary<string, string> userData)
        {
            ClientResult cr = Client.Register(email, userData);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "RESET_REGISTER");
                return GetStatusCode(cr);
            }

            return RetrieveCurrentStatus();
        }

        /// <summary>
        /// Activate the current workstation under a specific (pre-existing) subscription.
        /// </summary>
        /// <param name="subscriptionReference">A pre-existing subscription reference.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int BeginService(string subscriptionReference)
        {
            ClientResult cr = Client.BeginService(subscriptionReference);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "BEGIN_SERVICE");
                return GetStatusCode(cr);
            }

            // Now that we have acquired the licence we can call StartSession() again 
            return this.Start();
        }

        #endregion

        /// <summary>
        /// Check if the given command is available for the current service plan.
        /// Intended mostly for control logic of commands that should only appear under specific service plan(s).
        /// Note that it is equivalent to explicitly parsing the status value of key 'allowedCmds'.
        /// </summary>
        /// <param name="commandName">The name of a command.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int CommandAvailableCheck(string commandName)
        {
            ClientResult<bool> cr = Client.IsCommandAvailable(commandName);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "CMD_AVAILABLE");
                return GetStatusCode(cr);
            }
            
            // Show results in output
            string message = string.Format(
                " is {0}available for the current service plan", cr.Value ? "" : "NOT ");
            Display.ShowResponseData(message);

            return ResponseCode.OK;
        }

        /// <summary>
        /// Check whether the given, resource-bound command can be executed in the current license state.
        /// A request is sent to server each time to determine if the related resources have run out or not.
        /// </summary>
        /// <param name="commandName">The name of a command.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int CommandExecuteCheck(string commandName)
        {
            ClientResult<bool> cr = Client.CanExecuteCommand(commandName);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "CAN_EXEC_CMD");
                return GetStatusCode(cr);
            }

            // Show results in output
            string message = string.Format(
                " can {0}be executed in the current license state", cr.Value ? "" : "NOT ");
            Display.ShowResponseData(message);

            return ResponseCode.OK;
        }

        #region File API

        /// <summary>
        /// Upload the initial instance of a monitored file.
        /// If the file has already been created by another station,
        /// error code ResponseCode.FileCreateAlreadyExists is emitted.
        /// Respectively, if someone else is currently uploading the file,
        /// error ResponseCode.FileCreateOtherUploading is returned.
        /// </summary>
        /// <param name="filepath">The path of an existing file.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int CreateFileIfNotExists(string name, string filepath)
        {
            // Read raw byte content from disk (in an everyday scenario this will already be in-memory)
            byte[] content = File.ReadAllBytes(filepath);

            long startTick = DateTime.UtcNow.Ticks;
            
            ClientResult cr = Client.CreateFile(name, content);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "FILE_CREATE");
                return GetStatusCode(cr);
            }

            Console.WriteLine(string.Format(
                " File created successfully after {0} msec!",
                (DateTime.UtcNow.Ticks - startTick) / 10000.0));

            return ResponseCode.OK;
        }

        /// <summary>
        /// Synchronize local version of a monitored file, i.e. ping the server and
        /// download if a newer version exists.
        /// Note that CheckFileVersion() should be the very first File API call in every session.
        /// By design, the first call will always return 'hasNewerVersion' = true.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int SyncFileForWorkstation(string name)
        {
            // Check if the local signature of the file matches the latest version
            ClientResult<bool> cr = Client.HasNewerFileVersion(name) ;
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "FILE_SYNC");
                return GetStatusCode(cr);
            }
            bool hasNewerVersion = cr.Value;

            // If another workstation has modified the file or
            // this is the very first File API call, download it
            if (hasNewerVersion)
            {
                return GetLatestFileVersion(name);
            }
            else
            {
                Display.ShowResponseData(" The workstation is up-to-date.");
            }

            return ResponseCode.OK;
        }

        /// <summary>
        /// Try to upload a new version of a monitored file.
        /// Expects that at least one synchronization has been previously completed -
        /// if not, an error code of ResponseCode.FileNotSyncedYet is returned.
        /// If someone else has already uploaded another version of the file,
        /// an error code of ResponseCode.FileNewerVersionExists is returned.
        /// </summary>
        /// <param name="content">The raw byte content to upload.</param>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int UploadNewFileVersion(string name, byte[] content)
        {
            long startTick = DateTime.UtcNow.Ticks;

            ClientResult cr = Client.UpdateSynchronizedFile(name, content);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "FILE_UPLOAD");
                return GetStatusCode(cr);
            }

            Console.WriteLine(string.Format(
                " File updated successfully after {0} msec!",
                (DateTime.UtcNow.Ticks - startTick) / 10000.0));

            return ResponseCode.OK;
        }

        /// <summary>
        /// Download the latest version of a monitored file.
        /// If the file was never initiated an error code ResponseCode.FileNotFound is returned.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int GetLatestFileVersion(string name)
        {
            long startTick = DateTime.UtcNow.Ticks;

            // Download the latest version
            ClientResult<byte[]> cr = Client.GetFile(name);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "FILE_GET");
                return GetStatusCode(cr);
            }
            byte[] content = cr.Value;

            Display.ShowResponseData(string.Format(
                " The newest version of the file retrieved in {0} msec:",
                (DateTime.UtcNow.Ticks - startTick) / 10000.0));

            // Show the retrieved content (in an everyday scenario the caller will apply his own logic)
            string text = Encoding.UTF8.GetString(content);
            if (text.Length > 1000)
            {
                text = text.Substring(0, 1000);
            }
            Display.ShowResponseData(text);
            
            return ResponseCode.OK;
        }

        /// <summary>
        /// Get history of changes for a monitored file.
        /// Mostly useful for debugging or reporting purposes.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        public int ShowFileHistory(string name)
        {
            bool includeLatest = true;  // 'True' if you want to include the latest version
            int lastN = 50;            // Limit the number of returned results

            // Get a listing of changes in reverse chronological order
            ClientResult<Tuple<string, BlobInfo>[]> cr = 
                Client.GetFileHistory(name, includeLatest, lastN);
            if (cr.HasError)
            {
                Display.ShowErrors(cr.GetErrors(), "FILE_HISTORY");
                return GetStatusCode(cr);
            }
            Tuple<string, BlobInfo>[] history = cr.Value;

            Display.ShowResponseData(
                string.Format("Total {0} changes:", history.Length),
                history.Select(t => "  " + t.Item2.ToString()).ToList());

            return ResponseCode.OK;
        }

        #endregion

        /// <summary>
        /// Get the response code of the last client request.
        /// </summary>
        /// <returns>A <see cref="ResponseCode"/> status code.</returns>
        private int GetStatusCode<T>(ClientResult<T> cr)
        {
            return cr.HasError ? cr.LastError.Code : ResponseCode.OK;
        }
    }
}
