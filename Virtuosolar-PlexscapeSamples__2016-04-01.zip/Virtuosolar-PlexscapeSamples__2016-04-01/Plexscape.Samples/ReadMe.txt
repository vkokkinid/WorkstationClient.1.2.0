-----------------
About the samples
-----------------

This sample demonstrates the integration and use of workstation client, a proxy-like assembly 
that handles all communication towards Plexscape's web services (WS) infrastructure.

By invoking methods on this client one can benefit from the flexible licencing capabilities,
the enhanced security and protection from unauthorized copying/cracking, the monitoring of consumed
resources and the ability to provide extended evaluation trials to users.
All these features can be easily parameterized and customized according to the desired business scenario.


----------------
Typical workflow
----------------

1. LoadClient()
2. StartSession()
	2.1.
	 Case 'OK':
		- GetServiceStatus()
		- GetStatusValueForKey()
		- File API calls
		- IsCommandAvailable()
		- CanExecuteCommand()

	 Case 'WorkstationNotActivatedYet':
		- BeginAnonymousTrial()
		- StartRegisteredTrial() --> ConfirmRegisteredTrial()
								 --> ResetPendingRegistration()
								 --> ResetPendingRegistration() with a new email
		- BeginService()

	 Case of general error:
		Developers might delete subscription/workstation data via the web console.
		If the returned 'ClientError.ErrorReport' property has value, please forward 
		the generated report file to Plexscape for further investigation.

	2.2.
	 Repeat step 2.1, Case 'OK'

3. EndSession()


-------------------
Action Descriptions
-------------------

- GetClientInfo()
Get client information useful for troubleshooting purposes.
Depending on the overall workstation/subscription state, values are returned for
'DtoKeys.StationReference', 'DtoKeys.CallerIp', 'DtoKeys.SubReference', 'DtoKeys.SubName' etc.

- LoadClient()
Initialization of the client communicating with Plexscape's WS.
Requires application data, including product and version information, provided in key-value pair format.
Note that each computer running an instance of WorkstationClient is uniquely identified and considered a different "station".
So ,depending on the type of licencing various restrictions can be applied (read below for details).

- StartSession()
The first call in every session with the WS.
Depending on the state of the licence (called subscription, from now on) this call might:
- return success if a valid subscription exists
- return error if no subscription exists yet
A listing of the possible status codes can be found in the section below.

- EndSession()
The last call in every session with the WS.

- GetServiceStatus()
Get the current state of the workstation and the subscription it belongs to.
Also, this method returns information about the subscription type (called service plan, from now on),
the commands allowed
The declaration and configuration of all of the above is possible through Plexscape's management platform.
Note that in case of a status code other than 'OK', details about the error(s) can be retrieved through the result.

- GetStatusValueForKey()
Get one specific status value, as contained in the results of GetServiceStatus().
This is a method optimized for "heavy" access, i.e. avoids redundant server requests as much as possible.
Use it for GUI checks or other control logic that is expected to be frequent, e.g. multiple times within a minute.

- GetServicePlans()
Helper function that returns a listing of the supported subscription types.
Call this method providing the desired combination of filter arguments such as 
'PlexDtoKeys.IsTrial', 'PlexDtoKeys.NeedsRegistration'.

- BeginTrial()
When no prior subscription exists for a workstation the user can start a trial, 
either an anonymous or a registered one.
The first type will most likely have limited duration and resources assigned to it,
since it's something that will usually be offered free of charge.
The latter type of trial is more advanced and allows more control over who uses the program.
It's a multi-step process, where a valid email is requested and used as a recipient of a confirmation code.
The particular code must be provided as input for the second step to complete registration and
start using the software.

- Register(), ConfirmRegistration(), ResetPendingRegistration()
The steps needed to complete activation for a subscription that demands registration.

- BeginService()
Another available type of subscription where a licence must pre-exist.
A reference token (provided externally) must be passed to the WS in order to start using the licence.
In staging mode Plexscape provides sample subscriptions, with both limited and unlimited resources,
while more can be added to represent other business scenarios.

- IsCommandAvailable()
Check if the given command is available for the current service plan.
Intended mostly for control logic of commands that should only appear under a specific service plans.
Note that it is equivalent to explicitly parsing the status value of key 'allowedCmds'.

- CanExecuteCommand()
Check whether the given, resource-bound command can be executed in the current license state.
A request is sent to server each time to determine if the related resources have run out or not.

- HasNewerFileVersion(), GetFile(), UpdateSynchronizedFile(), CreateFile(), GetFileHistory()
API that provides the ability to store and synchronize one or more files between clients.
See the proposed implementation for details.


-------------
Release Notes
-------------

Version 1.0.0.0:
Initial release, 2014-06-20.

Version 1.0.0.1:
Support of workstation client v1.0.1.0, 2015-01-28.

Version 1.0.0.2:
Workstation client v1.0.1.1, 2015-03-10.
Common service environment for all clients.
Login to px-web-console site in order to clear subscription and workstation data.

Version 1.2.0.0:
Workstation client v1.2.0.1, 2016-02-26.
New generation codenamed "Bonnie" that supports file API, error reports and offline mode.
Also, asynchronous requests available for net45 builds.


