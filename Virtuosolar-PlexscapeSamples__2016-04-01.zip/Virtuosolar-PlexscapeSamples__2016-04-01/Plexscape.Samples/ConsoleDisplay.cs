﻿using Plexscape.WebServices.WorkstationClient;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Plexscape.Samples
{
    /// <summary>
    /// Implementation of <see cref="IDisplay"/>.
    /// Provides console output functionality.
    /// </summary>
    public class ConsoleDisplay : IDisplay
    {
        /// <summary>
        /// See <see cref="IDisplay.ShowErrors"/>.
        /// </summary>
        public void ShowErrors(IEnumerable<ClientError> errors, string action)
        {
            if (errors == null || errors.Count() == 0)
            {
                throw new ArgumentException("ShowErrors() should only be called when an error occured!");
            }

            string lastErrorReport = null;

            foreach (ClientError err in errors)
            {
                Console.WriteLine(" Error {0} for action '{1}', Message: {2}",
                    GetMessageForStatusCode(err.Code), action, err.Message);

                if (err.HasErrorReport())   // An error report was generated
                {
                    lastErrorReport = err.ErrorReport;
                    Console.WriteLine(string.Format(
                        " Pls forward to Plexscape the generated report file: '{0}'",
                        err.ErrorReport));
                }
            }

            // Show location of the last generated error report
            if (!string.IsNullOrWhiteSpace(lastErrorReport))
            {
                string argument = @"/select, " + lastErrorReport;
                Process.Start("explorer.exe", argument);
            }

            Console.WriteLine();
        }

        /// <summary>
        /// See <see cref="IDisplay.ShowResponseData"/>.
        /// </summary>
        public void ShowResponseData(string message, object data = null)
        {
            Console.WriteLine(message);

            if (data != null)
            {
                Dictionary<string, string> dictionary = data as Dictionary<string, string>;
                IEnumerable<string> collection = data as IEnumerable<string>;

                if (dictionary != null)
                {
                    foreach (KeyValuePair<string, string> kvp in dictionary)
                    {
                        Console.WriteLine(" ['{0}', '{1}']", kvp.Key, kvp.Value);
                    }
                }
                else if (collection != null)
                {
                    foreach (string text in collection)
                    {
                        Console.WriteLine(text);
                    }
                }
                else
                {
                    Console.WriteLine(data.ToString());
                }
            }
            
            Console.WriteLine();
        }

        /// <summary>
        /// Helper method that returns a textual representation of a <see cref="ResponseCode"/>.
        /// </summary>
        private static string GetMessageForStatusCode(int statusCode)
        {
            if (statusCode == ResponseCode.OK)  return "OK (0)";

            #region Server Errors

            else if (statusCode == ResponseCode.SERVER_ERROR_BASE)          return "SERVER_ERROR_BASE (10000)";       
            else if (statusCode == ResponseCode.WorkstationNotExists)       return "WorkstationNotExists (10001)";
            else if (statusCode == ResponseCode.WorkstationNotAllowed)      return "WorkstationNotAllowed (10002)";
            else if (statusCode == ResponseCode.UnauthorizedCaller)         return "UnauthorizedCaller (10003)";
            else if (statusCode == ResponseCode.WorkstationNotActivatedYet)     return "WorkstationNotActivatedYet (10010)";
            else if (statusCode == ResponseCode.CallerIpNotAllowed)         return "SubscriptionDeactivated (10011)";
            else if (statusCode == ResponseCode.SubscriptionNotAllowed)     return "SubscriptionNotAllowed (10012)";
            else if (statusCode == ResponseCode.SubscriptionExpired)        return "SubscriptionExpired (10013)";
            else if (statusCode == ResponseCode.ConstraintViolated)         return "ConstraintViolated (10014)";
            else if (statusCode == ResponseCode.CallerIpNotAllowed)         return "CallerIpNotAllowed (10015)";
            else if (statusCode == ResponseCode.PendingRegistration)        return "PendingRegistration (10016)";
            else if (statusCode == ResponseCode.PendingConfirmation)        return "PendingConfirmation (10017)";
            else if (statusCode == ResponseCode.AuthenticationFailed)       return "AuthenticationFailed (10018)";
            else if (statusCode == ResponseCode.BadRequestData)             return "BadRequestData (10100)";
            else if (statusCode == ResponseCode.InvalidCommand)             return "InvalidCommand (10101)";
            else if (statusCode == ResponseCode.NotAllowedCommand)          return "NotAllowedCommand (10102)";
            else if (statusCode == ResponseCode.InvalidSubscriptionReferenceSent)   return "InvalidSubscriptionReferenceSent (10103)";
            else if (statusCode == ResponseCode.InvalidServicePlanReference)        return "InvalidServicePlanReference (10104)";
            else if (statusCode == ResponseCode.InvalidApplicationReference)        return "InvalidApplicationReference (10105)";
            else if (statusCode == ResponseCode.InvalidEmailSent)           return "InvalidEmailSent (10106)";
            else if (statusCode == ResponseCode.InvalidConfirmationCodeSent)        return "InvalidConfirmationCodeSent (10107)";
            else if (statusCode == ResponseCode.InternalLogicError)         return "InternalLogicError (15000)";
            
            else if (statusCode < ResponseCode.CLIENT_ERROR_BASE)
            {
                return string.Format("Unspecified server error ({0})", statusCode);
            }

            #endregion

            #region Client Errors

            // General
            else if (statusCode == ResponseCode.CLIENT_ERROR_BASE)          return "CLIENT_ERROR_BASE (20000)";
            else if (statusCode == ResponseCode.FailedToInitialize)         return "FailedToInitialize (20001)";
            else if (statusCode == ResponseCode.InvalidRequestArgument)     return "InvalidRequestArgument (20002)";
            else if (statusCode == ResponseCode.InvalidClientOperation)     return "InvalidClientOperation (20003)";
            
            // Activation related
            else if (statusCode == ResponseCode.InvalidTrialServicePlanReference)   return "InvalidTrialServicePlanReference (20004)";
            else if (statusCode == ResponseCode.InvalidEmail)               return "InvalidEmail (20005)";
            else if (statusCode == ResponseCode.InvalidConfirmationCode)    return "InvalidConfirmationCode (20006)";
            else if (statusCode == ResponseCode.InvalidSubscriptionReference)       return "InvalidSubscriptionReference (20007)";
            else if (statusCode == ResponseCode.NotCheckedOutYet)           return "NotCheckedOutYet (20010)";
            
            // File API
            else if (statusCode == ResponseCode.InvalidFileApiOperation)    return "InvalidFileApiOperation (20100)";
            else if (statusCode == ResponseCode.FileNotMonitored)           return "FileNotMonitored (20101)";
            else if (statusCode == ResponseCode.FileNotFound)               return "FileNotFound (20102)";
            else if (statusCode == ResponseCode.FileNotSyncedYet)           return "FileNotSyncedYet (20103)";
            else if (statusCode == ResponseCode.FileFailedToBackup)         return "FileFailedToBackup (20104)";
            else if (statusCode == ResponseCode.FileNewerVersionExists)     return "FileNewerVersionExists (20105)";
            else if (statusCode == ResponseCode.FileCreateAlreadyExists)    return "FileCreateAlreadyExists (20106)";
            else if (statusCode == ResponseCode.FileCreateOtherUploading)   return "FileCreateOtherUploading (20106)";
            
            // Http requests
            else if (statusCode == ResponseCode.FailedToSendRequest)        return "FailedToSendRequest (21000)";
            else if (statusCode == ResponseCode.FailedToSerializeRequest)   return "FailedToSerializeRequest (21001)";
            else if (statusCode == ResponseCode.FailedToParseResponse)      return "FailedToParseResponse (21002)";
            else if (statusCode == ResponseCode.MissingResponseData)        return "MissingResponseData (21003)";
            
            // Offline mode
            else if (statusCode == ResponseCode.UnableToExecuteDueToOffline)        return "UnableToExecuteDueToOffline (21004)";
            
            else if (statusCode < ResponseCode.CUSTOM_ERROR_BASE)
            {
                return string.Format("Unspecified client error ({0})", statusCode);
            }

            #endregion

            // Any custom response codes defined by developer (statusCode >= 30000)
            return string.Format("Custom error ({0})", statusCode);
        }
    }
}