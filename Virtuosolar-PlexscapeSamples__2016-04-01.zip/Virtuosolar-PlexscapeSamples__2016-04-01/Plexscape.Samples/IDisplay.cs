﻿using Plexscape.WebServices.WorkstationClient;
using System.Collections.Generic;

namespace Plexscape.Samples
{
    /// <summary>
    /// Interface used to display output to an external source (i.e. decoupling of presentation logic).
    /// </summary>
    public interface IDisplay
    {
        /// <summary>
        /// Display the latest error(s).
        /// </summary>
        /// <param name="errors">A non-empty list of errors to display.</param>
        /// <param name="action">The name or a description of the related action.</param>
        void ShowErrors(IEnumerable<ClientError> errors, string action);

        /// <summary>
        /// Display unstructured response data returned by the server.
        /// </summary>
        /// <param name="message">A message to display along with the given data.</param>
        /// <param name="data">A response data object.</param>
        void ShowResponseData(string message, object data = null);
    }
}
