using System;
using System.Net;

namespace Plexscape.Samples
{
    /// <summary>
    /// Different modes of proxy connections.
    /// </summary>
    public enum ProxyConnectionMode
    {
        Auto, Manual, System
    }

    /// <summary>
    /// Utility class for web proxy related tasks.
    /// </summary>
    public static class ProxyUtils
    {
        /// <summary>
        /// Create an IWebProxy object for the given connection mode.
        /// </summary>
        /// <param name="proxyMode">The <see cref="ProxyConnectionMode"/>.</param>
        /// <param name="proxyAddress">Proxy address for manual mode.</param>
        /// <param name="credentials">Optional credentials for manual mode.</param>
        public static IWebProxy GetProxy(ProxyConnectionMode proxyMode,
            string proxyAddress = null, NetworkCredential credentials = null)
        {
            if (proxyMode == ProxyConnectionMode.Manual && string.IsNullOrEmpty(proxyAddress))
            {
                throw new ArgumentException("Missing settings for manual proxy mode!");
            }

            IWebProxy ret;

            switch (proxyMode)
            {
                case ProxyConnectionMode.Auto:
                    ret = new WebProxy();
                    break;
                
                case ProxyConnectionMode.Manual:
                    ret = new WebProxy() {
                        Address = new Uri(proxyAddress), Credentials = credentials
                    };
                    break;
                
                case ProxyConnectionMode.System:
                default:
                    ret = WebRequest.GetSystemWebProxy();
                    break;
            }

            return ret;
        }
    }
}
